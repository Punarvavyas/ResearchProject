library(dplyr)

mydata = read.csv("C:/Users/poitr/Desktop/robomission-2019-02-09 (2)/robomission-2019-02-09/snapshots.csv")  # read csv file 
data = filter(mydata, correct == "True" | correct == "False")
write.csv(data, "C:/Users/poitr/Desktop/robomission-2019-02-09 (2)/robomission-2019-02-09/snapshots_Rfilter.csv")

dataedits = filter(mydata, task == "32")
write.csv(dataedits, "C:/Users/poitr/Desktop/robomission-2019-02-09 (2)/robomission-2019-02-09/snapshots_Rfilter_edits.csv")
