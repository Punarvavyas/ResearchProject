import pandas as pd

class RoboMission:
    #loop through each program state
    #for attr, value in sheets_dict.program.items():
    #print(value)
    
    #create the vector
    def vector(token_list):
        array = []
        for i in token_list:
            x = i
            count = 0
            for j in token_list:
                if(i == j):
                    count = count + 1
                else:
                    pass
            print(x, str(count))
            array.append([x, count])
            count = 0
        print(array)

    #loop through characters
    def parser(state):
        print(state)
        token = ""
        token_list = []
        merge = False
        for i, v in enumerate(state):
            if(v == "R" and merge == False or v == "W" and merge == False):
                merge = True
                token = v
            elif(merge == True):
                merge = False
                token += v
                token_list.append(token)
            elif(v == "{" or v == "}"):
                pass
            else:
                token = v
                token_list.append(token)
            print(token_list)
        RoboMission.vector(token_list)

sheets_dict = pd.read_excel('C:/Users/poitr/Desktop/robomission-2019-02-09 (2)/robomission-2019-02-09/snapshots_WindowedSegments.xlsx')
RoboMission.parser(sheets_dict.program[0])